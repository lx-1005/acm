create
    definer = root@localhost procedure insert_emp(IN START int, IN max_num int)
BEGIN
    DECLARE i INT DEFAULT 0;

    SET autocommit = 0;
    REPEAT
        SET i = i + 1;
        INSERT INTO emp (empno, NAME ,age ,deptid ) VALUES ((START+i) ,rand_string(6)   , rand_num(30,50),rand_num(1,10000));
    UNTIL i = max_num
        END REPEAT;
    COMMIT;
END;

